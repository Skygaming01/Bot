import React from 'react'
import { motion } from 'framer-motion'

export default function Hero() {
  return (
    <section className="pt-28 px-6 text-center max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-5xl font-extrabold mb-4">
          Crimson Creation — Discord Agency & Marketplace
        </h1>
        <p className="text-lg text-gray-300 mb-6">
          Premium server setups, bots, graphics, and custom solutions made for clans, communities, and creators.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#services"
            className="px-6 py-3 bg-indigo-500 rounded-2xl font-semibold hover:brightness-105 transition"
          >
            Explore Services
          </a>
          <a
            href="https://discord.com" /* replace with your invite */
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 border border-indigo-500 rounded-2xl font-semibold hover:bg-indigo-600 transition"
          >
            Hire Us on Discord
          </a>
        </div>
      </motion.div>
    </section>
  )
}
