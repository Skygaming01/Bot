import React from 'react'
import { motion } from 'framer-motion'
import { Menu } from 'lucide-react'

export default function Navbar() {
  return (
    <motion.nav
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="w-full flex items-center justify-between px-6 py-4 bg-gradient-to-r from-[#1f2230] to-[#171826] backdrop-blur-md shadow-soft fixed top-0 z-50"
    >
      <div className="flex items-center gap-2">
        <div className="text-2xl font-bold text-indigo-400">Crimson Creation</div>
        <div className="text-sm text-gray-400">Agency</div>
      </div>
      <div className="hidden md:flex gap-8">
        <a href="#services" className="hover:underline">
          Services
        </a>
        <a href="#showcase" className="hover:underline">
          Showcase
        </a>
        <a href="#about" className="hover:underline">
          About
        </a>
      </div>
      <div className="flex items-center gap-4">
        <a
          href="https://discord.com" /* replace with your invite */
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2 bg-indigo-600 rounded-2xl text-sm font-medium hover:brightness-105 transition"
        >
          Contact on Discord
        </a>
        <div className="md:hidden">
          <Menu size={24} />
        </div>
      </div>
    </motion.nav>
  )
}
