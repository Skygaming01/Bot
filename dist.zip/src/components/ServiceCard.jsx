import React from 'react'
import { motion } from 'framer-motion'

export default function ServiceCard({ title, description, icon, tag }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="p-6 bg-[#1f2230] rounded-2xl shadow-soft flex flex-col gap-3 border border-[#2a2f47]"
    >
      <div className="flex items-center justify-between">
        <div className="text-xl font-semibold">{title}</div>
        {tag && (
          <div className="text-xs bg-indigo-500 px-2 py-1 rounded-full uppercase">
            {tag}
          </div>
        )}
      </div>
      <p className="text-sm text-gray-300 flex-1">{description}</p>
      <div className="mt-2 flex justify-end">
        <a
          href="https://discord.com" /* replace with invite */
          target="_blank"
          rel="noopener noreferrer"
          className="text-indigo-400 text-sm font-medium hover:underline"
        >
          Contact
        </a>
      </div>
    </motion.div>
  )
}
