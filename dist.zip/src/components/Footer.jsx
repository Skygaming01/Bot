import React from 'react'

export default function Footer() {
  return (
    <footer className="mt-20 py-10 bg-gradient-to-t from-[#171826] to-[#1f2230]">
      <div className="max-w-5xl mx-auto px-6 flex flex-col md:flex-row justify-between gap-8">
        <div>
          <div className="text-2xl font-bold text-indigo-400">Crimson Creation</div>
          <p className="text-sm text-gray-400 mt-2">
            Discord agency for bots, GFX, server setups, and more. Built with care.
          </p>
        </div>
        <div className="flex gap-16">
          <div>
            <div className="font-semibold mb-2">Services</div>
            <div className="flex flex-col gap-1 text-sm">
              <span>Bot Development</span>
              <span>Server Setup</span>
              <span>Graphics</span>
              <span>Custom Tools</span>
            </div>
          </div>
          <div>
            <div className="font-semibold mb-2">Connect</div>
            <div className="flex flex-col gap-1 text-sm">
              <a href="https://discord.com" target="_blank" rel="noopener noreferrer">
                Discord
              </a>
              <span>Instagram (TBD)</span>
              <span>YouTube (TBD)</span>
            </div>
          </div>
        </div>
      </div>
      <div className="text-center text-xs text-gray-500 mt-8">
        © {new Date().getFullYear()} Crimson Creation. All rights reserved.
      </div>
    </footer>
  )
}
