import React from 'react'
import { motion } from 'framer-motion'

export default function ShowcaseCard({ imageUrl, title, category }) {
  return (
    <motion.div whileHover={{ scale: 1.02 }} className="rounded-2xl overflow-hidden shadow-soft bg-[#1f2230]">
      <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${imageUrl})` }}></div>
      <div className="p-4">
        <div className="font-semibold">{title}</div>
        <div className="text-xs text-gray-400">{category}</div>
      </div>
    </motion.div>
  )
}
