import React from 'react'
import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import ServiceCard from './components/ServiceCard.jsx'
import ShowcaseCard from './components/ShowcaseCard.jsx'
import Footer from './components/Footer.jsx'

const services = [
  {
    title: 'Custom Discord Bots',
    description: 'Moderation, ticketing, automation, and integration bots tailored to your server.',
    tag: 'Popular'
  },
  {
    title: 'Server Setup',
    description: 'Full Discord server architecture: roles, channels, permissions, and onboarding flows.',
  },
  {
    title: 'Graphics & GFX',
    description: 'Thumbnails, banners, logos, and social media assets that stand out.',
  },
  {
    title: 'Community Tools',
    description: 'Giveaways, dashboards, status pages, and engagement systems.',
  }
]

const showcase = [
  {
    imageUrl: 'https://via.placeholder.com/400x300?text=Project+1',
    title: 'Legend Clan Server',
    category: 'Server Setup'
  },
  {
    imageUrl: 'https://via.placeholder.com/400x300?text=Project+2',
    title: 'Ticket System Bot',
    category: 'Bot Development'
  },
  {
    imageUrl: 'https://via.placeholder.com/400x300?text=Project+3',
    title: 'YouTube Banner Pack',
    category: 'GFX'
  },
  {
    imageUrl: 'https://via.placeholder.com/400x300?text=Project+4',
    title: 'Dashboard UI',
    category: 'Tools'
  }
]

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <section id="services" className="max-w-6xl mx-auto px-6 mt-20">
          <h2 className="text-3xl font-bold mb-6 text-center">Our Services</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {services.map((s) => (
              <ServiceCard key={s.title} title={s.title} description={s.description} tag={s.tag} />
            ))}
          </div>
        </section>
        <section id="showcase" className="max-w-6xl mx-auto px-6 mt-24">
          <h2 className="text-3xl font-bold mb-6 text-center">Showcase</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {showcase.map((s) => (
              <ShowcaseCard key={s.title} imageUrl={s.imageUrl} title={s.title} category={s.category} />
            ))}
          </div>
        </section>
        <section id="about" className="max-w-4xl mx-auto px-6 mt-24 text-center">
          <h2 className="text-3xl font-bold mb-4">About Crimson Creation</h2>
          <p className="text-gray-300 mb-6">
            We’re a Discord-focused agency helping communities grow with custom bots, server architecture,
            and eye-catching graphics. Built by creators, for creators. Fast turnaround, reliable support,
            and a clean aesthetic.
          </p>
          <a
            href="https://discord.com" /* replace with your invite */
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 bg-indigo-500 rounded-2xl font-semibold hover:brightness-105 transition"
          >
            Join Our Discord
          </a>
        </section>
      </main>
      <Footer />
    </div>
  )
}
